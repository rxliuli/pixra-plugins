// src/plugin.ts
import * as pixra from "@pixra/plugin-sdk";
var DEFAULT_PADDING = 2;
var ALPHA_THRESHOLD = 10;
function findContentBounds(imageData, alphaThreshold = ALPHA_THRESHOLD) {
  const { width, height, data } = imageData;
  let minX = width;
  let minY = height;
  let maxX = -1;
  let maxY = -1;
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const alpha = data[(y * width + x) * 4 + 3];
      if (alpha > alphaThreshold) {
        minX = Math.min(minX, x);
        minY = Math.min(minY, y);
        maxX = Math.max(maxX, x);
        maxY = Math.max(maxY, y);
      }
    }
  }
  if (maxX < 0 || maxY < 0) {
    return null;
  }
  return {
    x: minX,
    y: minY,
    width: maxX - minX + 1,
    height: maxY - minY + 1
  };
}
function applyPadding(bounds, padding, imageWidth, imageHeight) {
  const x = Math.max(0, bounds.x - padding);
  const y = Math.max(0, bounds.y - padding);
  const right = Math.min(imageWidth, bounds.x + bounds.width + padding);
  const bottom = Math.min(imageHeight, bounds.y + bounds.height + padding);
  return {
    x,
    y,
    width: right - x,
    height: bottom - y
  };
}
function cropImageData(imageData, bounds) {
  const { x, y, width, height } = bounds;
  const { width: srcWidth, data: srcData } = imageData;
  const croppedData = new Uint8ClampedArray(width * height * 4);
  for (let row = 0; row < height; row++) {
    const srcOffset = ((y + row) * srcWidth + x) * 4;
    const destOffset = row * width * 4;
    croppedData.set(srcData.slice(srcOffset, srcOffset + width * 4), destOffset);
  }
  return new ImageData(croppedData, width, height);
}
async function smartCrop() {
  const imageData = await pixra.workspace.getActiveImage();
  if (!imageData) {
    await pixra.window.showErrorMessage("No image is currently open");
    return;
  }
  const bounds = findContentBounds(imageData);
  if (!bounds) {
    await pixra.window.showWarningMessage(
      "No content found - image appears to be fully transparent"
    );
    return;
  }
  if (bounds.x === 0 && bounds.y === 0 && bounds.width === imageData.width && bounds.height === imageData.height) {
    await pixra.window.showInformationMessage(
      "Image already has no transparent edges to crop"
    );
    return;
  }
  const paddedBounds = applyPadding(
    bounds,
    DEFAULT_PADDING,
    imageData.width,
    imageData.height
  );
  const croppedImage = cropImageData(imageData, paddedBounds);
  await pixra.workspace.updateActiveImage(croppedImage);
}
function activate(context) {
  const disposable = pixra.commands.registerCommand("smartCrop.crop", smartCrop);
  context.subscriptions.push(disposable);
}
function deactivate() {
}
export {
  activate,
  deactivate
};
//# sourceMappingURL=plugin.js.map
